const ITEMS = [
  "Brand Identity",
  "Logo Design",
  "Editorial Layout",
  "Social Media",
  "Poster Design",
  "Book Covers",
  "Photo Retouching",
  "AI Video",
  "Arabic Typography",
  "HTML & CSS",
];

export function Marquee({ reverse = false }: { reverse?: boolean }) {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div
      className="marquee group relative overflow-hidden border-y border-line bg-[color-mix(in_srgb,var(--panel)_45%,transparent)] py-4 backdrop-blur-sm md:py-5"
      aria-label="Design capabilities"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-[var(--bg)] to-transparent md:w-28"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-[var(--bg)] to-transparent md:w-28"
      />
      <div className={`marquee-track ${reverse ? "marquee-reverse" : ""}`} style={{ "--speed": "46s" } as React.CSSProperties}>
        {row.map((item, i) => (
          <span key={`${item}-${i}`} className="flex shrink-0 items-center gap-5 pr-5 md:gap-8 md:pr-8" aria-hidden={i >= ITEMS.length}>
            <span className="whitespace-nowrap font-display text-lg italic tracking-wide text-ink/85 md:text-xl">{item}</span>
            <span className="text-[0.55rem] text-gold" aria-hidden="true">✳</span>
          </span>
        ))}
      </div>
    </div>
  );
}
