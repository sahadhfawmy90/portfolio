import type { ElementType, ReactNode } from "react";
import { cn } from "@/utils/cn";
import { Icon } from "@/components/Icons";
import { useMagnetic } from "@/hooks";
import { FIVERR_URL } from "@/data";

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
}) {
  return (
    <Tag
      data-reveal=""
      className={className}
      style={{ "--delay": `${delay}ms` } as React.CSSProperties}
    >
      {children}
    </Tag>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#top" className="group flex items-center gap-3" aria-label="Sahadh Fawmy — back to top">
      <span className="relative grid size-10 shrink-0 place-items-center overflow-hidden rounded-[13px] border border-gold/40 bg-[linear-gradient(145deg,rgba(214,182,139,0.22),rgba(155,131,245,0.12))]">
        <span className="font-display text-[1.15rem] italic leading-none text-gold-soft">SF</span>
        <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-[0.8rem] font-semibold tracking-[0.16em] text-ink">SAHADH FAWMY</span>
          <span className="label mt-1 !text-[0.5rem] !tracking-[0.2em]">Designer · Creator</span>
        </span>
      )}
    </a>
  );
}

export function SectionHead({
  index,
  eyebrow,
  title,
  intro,
  className,
  aside,
}: {
  index: string;
  eyebrow: string;
  title: ReactNode;
  intro?: ReactNode;
  className?: string;
  aside?: ReactNode;
}) {
  return (
    <div className={cn("flex flex-col gap-7", className)}>
      <Reveal className="flex items-center gap-4">
        <span className="label !text-gold">{index}</span>
        <span className="h-px w-10 bg-gold/50" />
        <span className="label">{eyebrow}</span>
      </Reveal>
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between lg:gap-16">
        <Reveal delay={80}>
          <h2 className="max-w-[18ch] text-balance text-[clamp(2.1rem,4.6vw,3.9rem)] font-medium leading-[1.03] tracking-[-0.035em]">
            {title}
          </h2>
        </Reveal>
        {(intro || aside) && (
          <Reveal delay={160} className="max-w-md lg:pb-2">
            {intro && <p className="text-[0.95rem] leading-relaxed text-muted">{intro}</p>}
            {aside}
          </Reveal>
        )}
      </div>
    </div>
  );
}

export function MagneticLink({
  href,
  children,
  variant = "gold",
  className,
  external = false,
  icon = "arrow",
  ariaLabel,
}: {
  href: string;
  children: ReactNode;
  variant?: "gold" | "ghost";
  className?: string;
  external?: boolean;
  icon?: string | null;
  ariaLabel?: string;
}) {
  const magnetic = useMagnetic(variant === "gold" ? 9 : 6);
  return (
    <a
      ref={magnetic.ref}
      href={href}
      aria-label={ariaLabel}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      onPointerMove={magnetic.onPointerMove}
      onPointerLeave={magnetic.onPointerLeave}
      className={cn("btn group", variant === "gold" ? "btn-gold" : "btn-ghost", className)}
    >
      <span>{children}</span>
      {icon && (
        <Icon
          name={icon}
          className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
        />
      )}
    </a>
  );
}

export function FiverrButton({ className, label = "Hire me on Fiverr" }: { className?: string; label?: string }) {
  return (
    <MagneticLink href={FIVERR_URL} external className={className} icon="arrow">
      {label}
    </MagneticLink>
  );
}

export function Availability({ className }: { className?: string }) {
  return (
    <div className={cn("inline-flex items-center gap-2.5", className)}>
      <span className="relative grid size-2 place-items-center">
        <span className="live-dot absolute size-2 rounded-full bg-[#86d9a5]" />
        <span className="size-1.5 rounded-full bg-[#86d9a5]" />
      </span>
      <span className="label !text-[0.58rem] !text-ink/80">Available for freelance</span>
    </div>
  );
}

export function Chip({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-2.5 py-1 font-mono text-[0.6rem] uppercase tracking-[0.12em] text-muted",
        className,
      )}
    >
      {children}
    </span>
  );
}

/** Decorative corner registration marks for the design-studio feel. */
export function CornerMarks({ className }: { className?: string }) {
  return (
    <div aria-hidden="true" className={cn("pointer-events-none absolute inset-0", className)}>
      <span className="absolute left-4 top-4 size-3 border-l border-t border-line-strong" />
      <span className="absolute right-4 top-4 size-3 border-r border-t border-line-strong" />
      <span className="absolute bottom-4 left-4 size-3 border-b border-l border-line-strong" />
      <span className="absolute bottom-4 right-4 size-3 border-b border-r border-line-strong" />
    </div>
  );
}
