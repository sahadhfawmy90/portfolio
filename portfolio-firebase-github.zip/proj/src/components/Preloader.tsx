import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "@/hooks";

export function Preloader({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [exiting, setExiting] = useState(false);
  const reduced = useReducedMotion();
  const done = useRef(false);

  useEffect(() => {
    const total = reduced ? 220 : 950;
    const start = performance.now();
    let frame = 0;
    const timers: number[] = [];

    const tick = (now: number) => {
      const p = Math.min((now - start) / total, 1);
      const eased = 1 - Math.pow(1 - p, 2.2);
      setProgress(Math.round(eased * 100));
      if (p < 1) {
        frame = requestAnimationFrame(tick);
      } else if (!done.current) {
        done.current = true;
        timers.push(window.setTimeout(() => setExiting(true), 140));
        timers.push(window.setTimeout(onDone, reduced ? 200 : 640));
      }
    };
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [onDone, reduced]);

  return (
    <>
      <span className="sr-only" role="status">
        Loading portfolio
      </span>
      <div
        className={`fixed inset-0 z-[100] flex flex-col justify-between overflow-hidden bg-bg px-5 py-6 md:px-10 md:py-8 ${
          exiting ? "loader-exit" : ""
        }`}
        aria-hidden="true"
      >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 size-[42rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-line opacity-70"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 size-[28rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-line opacity-50"
      />
      <div
        aria-hidden="true"
        className="orb absolute left-1/2 top-1/2 size-64 -translate-x-1/2 -translate-y-1/2 bg-violet/20"
      />

      <div className="relative flex items-center justify-between">
        <span className="label">Sahadh Fawmy</span>
        <span className="label">Colombo · LK</span>
      </div>

      <div className="relative mx-auto flex w-full max-w-xl flex-col items-center text-center">
        <div className="grid size-16 place-items-center rounded-2xl border border-gold/40 bg-[linear-gradient(145deg,rgba(214,182,139,0.2),rgba(155,131,245,0.12))]">
          <span className="font-display text-3xl italic text-gold-soft">SF</span>
        </div>
        <p className="label mt-6">Preparing the studio</p>
        <p className="mt-3 font-display text-[clamp(1.7rem,4vw,2.6rem)] italic leading-tight text-ink">
          Design is in the details.
        </p>
        <div className="mt-9 h-px w-full overflow-hidden bg-line">
          <div
            className="loader-line h-px transition-[width] duration-150 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-3 flex w-full items-center justify-between">
          <span className="label !text-[0.55rem]">Loading assets</span>
          <span className="font-mono text-[0.7rem] text-gold tabular-nums">
            {String(progress).padStart(3, "0")}
          </span>
        </div>
      </div>

      <div className="relative flex items-center justify-between">
        <span className="label !text-[0.55rem]">Graphic designer · Digital creator</span>
        <span className="label !text-[0.55rem]">Portfolio 2026</span>
      </div>
      </div>
    </>
  );
}
