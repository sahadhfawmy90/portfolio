import heroArt from "@/assets/hero-art.jpg";
import { FIVERR_URL, HERO_STATS } from "@/data";
import { useParallax, useTilt } from "@/hooks";
import { Icon } from "@/components/Icons";
import { Availability, MagneticLink, Reveal } from "@/components/ui";

function CircularSeal() {
  return (
    <div className="glass absolute -right-3 top-[13%] z-30 grid size-[5.4rem] place-items-center rounded-full shadow-2xl sm:-right-6 sm:size-24">
      <svg viewBox="0 0 120 120" className="spin-slow absolute inset-0 size-full p-2" aria-hidden="true">
        <defs>
          <path
            id="seal-circle"
            d="M60,60 m-43,0 a43,43 0 1,1 86,0 a43,43 0 1,1 -86,0"
          />
        </defs>
        <text className="fill-gold font-mono text-[8px] uppercase" style={{ letterSpacing: "2.6px" }}>
          <textPath href="#seal-circle">Graphic design · Digital creation ·</textPath>
        </text>
      </svg>
      <Icon name="spark" className="size-5 text-gold" />
    </div>
  );
}

function HeroScene() {
  const tilt = useTilt(9);
  const parallax = useParallax(0.032, 26);

  return (
    <div className="relative mx-auto w-full max-w-[480px] lg:max-w-none">
      <div ref={parallax}>
      <div
        ref={tilt.ref}
        onPointerMove={tilt.onPointerMove}
        onPointerLeave={tilt.onPointerLeave}
        className="tilt relative mx-auto aspect-[4/5] w-full max-w-[440px] [perspective:1200px] sm:max-w-[470px]"
      >
        {/* ambient light */}
        <div aria-hidden="true" className="absolute inset-0">
          <div className="orb absolute right-[-12%] top-[-6%] size-64 bg-violet/25" />
          <div className="orb absolute bottom-[-8%] left-[-14%] size-56 bg-gold/15" />
        </div>

        {/* offset frame */}
        <div
          aria-hidden="true"
          className="absolute inset-[3.5%] translate-x-3 translate-y-3 rounded-[30px] border border-gold/25 sm:translate-x-4 sm:translate-y-4"
        />

        {/* orbit rings */}
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="orbit-x aspect-square w-[112%] rounded-full border border-gold/20">
            <span className="absolute left-1/2 top-0 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold shadow-[0_0_18px_4px_rgba(214,182,139,0.4)]" />
          </div>
          <div className="absolute aspect-square w-[92%] rounded-full border border-line-strong/60" />
        </div>

        {/* main artwork card */}
        <div className="absolute inset-[7%] overflow-hidden rounded-[26px] border border-line-strong bg-[#08080d] shadow-[0_50px_120px_-40px_rgba(0,0,0,0.95)] [transform:translateZ(30px)]">
          <img
            src={heroArt}
            alt="Abstract 3D art direction study: obsidian ribbon, metallic gold torus and lavender glass"
            className="size-full object-cover"
            loading="eager"
            decoding="async"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,6,10,0.55)_0%,transparent_32%,transparent_58%,rgba(6,6,10,0.9)_100%)]"
          />
          <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4 sm:p-5">
            <span className="rounded-full border border-white/15 bg-black/30 px-2.5 py-1 font-mono text-[0.52rem] uppercase tracking-[0.18em] text-white/70 backdrop-blur-sm">
              Art direction
            </span>
            <span className="font-mono text-[0.52rem] uppercase tracking-[0.18em] text-white/50">SF — 001</span>
          </div>
          <div className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
            <div className="flex items-end justify-between gap-3">
              <div>
                <p className="font-mono text-[0.5rem] uppercase tracking-[0.2em] text-white/50">Visual study</p>
                <p className="mt-1 font-display text-xl italic leading-none text-white sm:text-2xl">
                  Form, light &amp; depth
                </p>
              </div>
              <div className="flex gap-1.5" aria-hidden="true">
                <span className="size-4 rounded-full border border-white/20 bg-[#d6b68b]" />
                <span className="size-4 rounded-full border border-white/20 bg-[#9b83f5]" />
                <span className="size-4 rounded-full border border-white/20 bg-[#f0dfc4]" />
                <span className="size-4 rounded-full border border-white/20 bg-[#12121c]" />
              </div>
            </div>
          </div>
        </div>

        {/* floating availability card */}
        <div className="absolute -left-2 top-[9%] z-30 [transform:translateZ(70px)] sm:-left-6">
          <div className="glass floaty rounded-2xl px-3.5 py-3 shadow-2xl">
            <p className="font-mono text-[0.5rem] uppercase tracking-[0.2em] text-muted">Currently</p>
            <div className="mt-1.5 flex items-center gap-2">
              <span className="live-dot size-1.5 rounded-full bg-[#86d9a5]" />
              <p className="text-[0.76rem] font-medium leading-none">Open for freelance</p>
            </div>
          </div>
        </div>

        <CircularSeal />

        {/* floating toolkit card */}
        <div className="absolute -bottom-3 -left-1 z-30 [transform:translateZ(85px)] sm:-left-7">
          <div className="glass floaty-slow rounded-2xl p-3.5 shadow-2xl">
            <div className="flex items-center justify-between gap-4">
              <p className="font-mono text-[0.5rem] uppercase tracking-[0.2em] text-muted">Toolkit</p>
              <Icon name="layers" className="size-3.5 text-gold" />
            </div>
            <div className="mt-2 flex gap-1.5">
              {["Ps", "Ai", "HTML"].map((tool) => (
                <span
                  key={tool}
                  className="rounded-md border border-line-strong bg-[#0b0b13] px-2 py-1 font-mono text-[0.58rem] tracking-wide text-[#e6e2da]"
                >
                  {tool}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* monogram tile */}
        <div className="absolute -right-1 bottom-[16%] z-20 hidden [transform:translateZ(55px)] sm:block">
          <div className="floaty grid size-16 place-items-center rounded-2xl border border-[#d6b68b]/35 bg-[linear-gradient(150deg,#191426,#0a0a10)] shadow-[0_24px_50px_-20px_rgba(0,0,0,0.9)] [animation-delay:-2s]">
            <span className="font-display text-2xl italic text-[#e4cba6]">SF</span>
          </div>
        </div>

        {/* location microcard */}
        <div className="glass absolute -right-2 top-[62%] z-20 hidden rounded-xl px-3 py-2 shadow-xl [transform:translateZ(45px)] md:block">
          <p className="font-mono text-[0.46rem] uppercase tracking-[0.18em] text-muted">Based in</p>
          <p className="mt-1 text-[0.68rem] font-medium">Colombo · 06°55′N</p>
        </div>
      </div>

      <div className="mt-7 flex items-center justify-between px-1">
        <span className="label !text-[0.52rem]">Fig. 01 — Visual direction study</span>
        <span className="hidden items-center gap-2 text-muted [@media(hover:hover)_and_(pointer:fine)]:flex">
          <Icon name="cursor" className="size-3.5 text-gold" />
          <span className="label !text-[0.52rem]">Move to explore</span>
        </span>
      </div>
      </div>
    </div>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative z-[1] overflow-hidden pt-[104px] md:pt-[120px]">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="dot-grid absolute inset-x-0 top-0 h-[70%] text-line-strong opacity-25 [mask-image:radial-gradient(70%_60%_at_50%_30%,black,transparent)]" />
        <div className="absolute inset-y-0 left-1/2 hidden w-px -translate-x-1/2 bg-gradient-to-b from-line-strong via-transparent to-transparent lg:block" />
        {[
          { l: "8%", t: "22%", s: 3, c: "bg-gold", d: 0 },
          { l: "18%", t: "68%", s: 2, c: "bg-lav", d: -1.8 },
          { l: "37%", t: "14%", s: 2, c: "bg-gold", d: -3.4 },
          { l: "46%", t: "82%", s: 3, c: "bg-violet", d: -2.2 },
          { l: "62%", t: "9%", s: 2, c: "bg-lav", d: -4.1 },
          { l: "72%", t: "48%", s: 2, c: "bg-gold", d: -0.9 },
          { l: "84%", t: "26%", s: 3, c: "bg-violet", d: -2.7 },
          { l: "92%", t: "72%", s: 2, c: "bg-gold", d: -1.2 },
          { l: "28%", t: "42%", s: 2, c: "bg-lav", d: -3.9 },
          { l: "56%", t: "62%", s: 2, c: "bg-gold", d: -0.4 },
        ].map((p, i) => (
          <span
            key={i}
            className={`floaty-slow absolute rounded-full ${p.c} opacity-40`}
            style={{
              left: p.l,
              top: p.t,
              width: p.s,
              height: p.s,
              animationDelay: `${p.d}s`,
            }}
          />
        ))}
      </div>

      <div className="container-x relative flex min-h-[calc(100svh-104px)] flex-col justify-center pb-10 pt-8 md:pb-14">
        <div className="grid items-center gap-12 lg:grid-cols-12 lg:gap-8">
          <div className="relative lg:col-span-7 lg:pr-4">
            <Reveal className="flex flex-wrap items-center gap-x-4 gap-y-3">
              <Availability />
              <span className="hidden h-3 w-px bg-line-strong sm:block" />
              <span className="label flex items-center gap-2 !text-[0.56rem]">
                <Icon name="compass" className="size-3 text-gold" />
                Colombo, Sri Lanka · Working worldwide
              </span>
            </Reveal>

            <Reveal delay={80}>
              <h1 className="mt-6 md:mt-8">
                <span className="sr-only">Sahadh Fawmy — Graphic Designer and Digital Creator. </span>
                <span aria-hidden="true" className="display-name block text-ink">
                  SAHADH
                </span>
                <span aria-hidden="true" className="display-serif gold-text block pr-2">
                  FAWMY
                </span>
              </h1>
            </Reveal>

            <Reveal delay={150} className="mt-5 flex items-center gap-3">
              <span className="h-px w-8 bg-gold/70" />
              <p className="label !text-[0.58rem] !text-ink/85 sm:!text-[0.65rem]">
                Graphic Designer <span className="text-gold">&amp;</span> Digital Creator
              </p>
            </Reveal>

            <Reveal delay={210}>
              <p className="mt-6 max-w-[24ch] font-display text-[clamp(1.55rem,3.2vw,2.35rem)] leading-[1.12] tracking-[-0.01em] text-ink">
                Turning creative ideas into <em className="text-gold-soft">powerful</em> visual experiences.
              </p>
            </Reveal>

            <Reveal delay={270}>
              <p className="mt-5 max-w-[50ch] text-[0.92rem] leading-relaxed text-muted sm:text-[0.97rem]">
                I&apos;m Sahadh Fawmy, a Graphic Designer and Digital Creator passionate about creating
                meaningful visual identities, professional designs, and engaging digital experiences.
              </p>
            </Reveal>

            <Reveal delay={330} className="mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
              <MagneticLink href="#work" variant="gold" icon="arrow">
                Explore my work
              </MagneticLink>
              <MagneticLink href={FIVERR_URL} variant="ghost" external icon="fiverr">
                Hire me on Fiverr
              </MagneticLink>
            </Reveal>

            <Reveal delay={390} className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-2">
              <a
                href={FIVERR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="link-underline group inline-flex items-center gap-2 text-[0.78rem] text-muted transition-colors hover:text-ink"
              >
                <span className="grid size-6 place-items-center rounded-full border border-line text-gold">
                  <Icon name="fiverr" className="size-3" />
                </span>
                View my Fiverr profile
                <Icon name="arrow" className="size-3 transition-transform group-hover:translate-x-0.5" />
              </a>
              <span className="text-[0.72rem] text-muted/70">International freelance · 3.5+ years</span>
            </Reveal>
          </div>

          <Reveal delay={220} className="lg:col-span-5">
            <HeroScene />
          </Reveal>
        </div>

        <Reveal delay={440} className="mt-12 md:mt-16">
          <div className="flex flex-col gap-6 border-t border-line pt-6 md:flex-row md:items-center md:justify-between md:gap-10">
            <dl className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4 sm:gap-x-10">
              {HERO_STATS.map((stat) => (
                <div key={stat.label}>
                  <dt className="sr-only">{stat.label}</dt>
                  <dd>
                    <span className="block text-[1.4rem] font-medium leading-none tracking-[-0.03em] text-ink">
                      {stat.value}
                    </span>
                    <span className="mt-1.5 block font-mono text-[0.53rem] uppercase tracking-[0.16em] text-muted">
                      {stat.label}
                    </span>
                  </dd>
                </div>
              ))}
            </dl>
            <a
              href="#about"
              className="group hidden items-center gap-3 self-end text-muted transition-colors hover:text-ink md:flex"
              aria-label="Scroll to about section"
            >
              <span className="label !text-[0.52rem]">Scroll to discover</span>
              <span className="grid size-10 place-items-center rounded-full border border-line transition-colors group-hover:border-gold">
                <Icon name="arrow" className="size-4 rotate-90 text-gold transition-transform group-hover:translate-y-0.5" />
              </span>
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
