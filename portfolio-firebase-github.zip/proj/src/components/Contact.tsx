import { useEffect, useState } from "react";
import { scrollToElement } from "@/hooks";
import { cn } from "@/utils/cn";
import { CONTACT_CHANNELS, FIVERR_URL, SERVICES, SOCIALS } from "@/data";
import { Icon } from "@/components/Icons";
import { Availability, Reveal } from "@/components/ui";

type Values = {
  name: string;
  email: string;
  service: string;
  budget: string;
  message: string;
};

const INITIAL: Values = {
  name: "",
  email: "",
  service: "",
  budget: "Let's discuss",
  message: "",
};

const BUDGETS = ["Let's discuss", "Under $50", "$50 – $150", "$150 – $500", "$500+"];
const SERVICE_OPTIONS = [...SERVICES.map((s) => s.title), "Something else"];

function FieldError({ id, children }: { id: string; children?: string }) {
  if (!children) return null;
  return (
    <p id={id} className="mt-1.5 flex items-center gap-1.5 text-[0.7rem] text-danger" role="alert">
      <Icon name="close" className="size-3" />
      {children}
    </p>
  );
}

export function Contact({ interest }: { interest: { title: string; id: number } }) {
  const [values, setValues] = useState<Values>(INITIAL);
  const [errors, setErrors] = useState<Partial<Record<keyof Values, string>>>({});
  const [status, setStatus] = useState<"idle" | "prepared">("idle");
  const [prefilled, setPrefilled] = useState(false);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "failed">("idle");

  useEffect(() => {
    if (!interest.title) return;
    setValues((v) => ({ ...v, service: interest.title }));
    setPrefilled(true);
    setStatus("idle");
  }, [interest]);

  function validateField(field: keyof Values, value: string): string | undefined {
    const trimmed = value.trim();
    if (field === "name") {
      if (trimmed.length < 2) return "Please tell me your name (at least 2 characters).";
    }
    if (field === "email") {
      if (!trimmed) return "An email address is needed so I can reply.";
      if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(trimmed)) return "That email address doesn't look right.";
    }
    if (field === "service" && !trimmed) return "Choose the service you're interested in.";
    if (field === "message") {
      if (trimmed.length < 20) return "A few more details please — at least 20 characters.";
      if (trimmed.length > 2000) return "Please keep the brief under 2,000 characters.";
    }
    return undefined;
  }

  function validateAll(v: Values) {
    const next: Partial<Record<keyof Values, string>> = {};
    (["name", "email", "service", "message"] as const).forEach((field) => {
      const error = validateField(field, v[field]);
      if (error) next[field] = error;
    });
    return next;
  }

  function update(field: keyof Values, value: string) {
    setValues((v) => ({ ...v, [field]: value }));
    if (errors[field]) {
      setErrors((e) => ({ ...e, [field]: validateField(field, value) }));
    }
    if (copyState !== "idle") setCopyState("idle");
  }

  function handleBlur(field: keyof Values) {
    const error = validateField(field, values[field]);
    setErrors((e) => ({ ...e, [field]: error }));
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validateAll(values);
    setErrors(nextErrors);
    const firstInvalid = (Object.keys(nextErrors) as (keyof Values)[])[0];
    if (firstInvalid) {
      document.getElementById(`brief-${firstInvalid}`)?.focus();
      return;
    }
    setStatus("prepared");
    window.setTimeout(() => {
      scrollToElement(document.getElementById("brief-result"), "center");
    }, 80);
  }

  const briefText = `Project brief — Sahadh Fawmy
Name: ${values.name}
Email: ${values.email}
Service: ${values.service}
Budget: ${values.budget}
Details: ${values.message}`;

  async function copyBrief() {
    try {
      await navigator.clipboard.writeText(briefText);
      setCopyState("copied");
    } catch {
      setCopyState("failed");
    }
  }

  return (
    <section id="contact" className="section-pad relative overflow-hidden">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="orb absolute -left-24 top-10 size-80 bg-gold/10" />
        <div className="orb absolute -right-24 bottom-0 size-96 bg-violet/15" />
        <div className="dot-grid absolute inset-x-0 bottom-0 h-64 text-line-strong opacity-20 [mask-image:linear-gradient(to_top,black,transparent)]" />
      </div>

      <div className="container-x relative">
        <Reveal className="flex items-center gap-4">
          <span className="label !text-gold">06</span>
          <span className="h-px w-10 bg-gold/50" />
          <span className="label">Contact &amp; hire</span>
        </Reveal>

        <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-8">
            <Reveal delay={60}>
              <h2 className="text-balance text-[clamp(2.3rem,5.6vw,4.6rem)] font-medium leading-[0.98] tracking-[-0.045em]">
                Let&apos;s create something{" "}
                <span className="serif-accent gold-text">amazing</span> together.
              </h2>
            </Reveal>
            <Reveal delay={130}>
              <p className="mt-5 max-w-xl text-[0.95rem] leading-relaxed text-muted">
                Have a project in mind? Let&apos;s turn your ideas into creative and professional visual
                experiences.
              </p>
            </Reveal>
          </div>
          <Reveal delay={190} className="lg:col-span-4 lg:justify-self-end">
            <div className="flex flex-col items-start gap-3 lg:items-end">
              <Availability />
              <a
                href={FIVERR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-gold group"
              >
                Hire me on Fiverr
                <Icon name="arrow" className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
              <p className="font-mono text-[0.5rem] uppercase tracking-[0.16em] text-muted">
                Replies via Fiverr · Colombo GMT+5:30
              </p>
            </div>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-12 lg:gap-8">
          {/* channels */}
          <div className="space-y-3 lg:col-span-5">
            <Reveal>
              <p className="label mb-2">Direct channels</p>
            </Reveal>

            {CONTACT_CHANNELS.map((channel, i) => (
              <Reveal key={channel.label} delay={i * 70}>
                <a
                  href={channel.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    "group flex items-center gap-4 rounded-2xl border p-4 transition-all duration-300",
                    channel.label === "Fiverr"
                      ? "border-gold/35 bg-[linear-gradient(120deg,rgba(214,182,139,0.13),rgba(155,131,245,0.07))] hover:border-gold/60"
                      : "border-line bg-surface hover:border-line-strong",
                  )}
                >
                  <span className="grid size-11 shrink-0 place-items-center rounded-xl border border-line bg-bg/40 text-gold">
                    <Icon name={channel.icon} className="size-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="text-[0.9rem] font-medium text-ink">{channel.label}</span>
                      <span className="rounded-full border border-line px-1.5 py-0.5 font-mono text-[0.42rem] uppercase tracking-[0.12em] text-muted">
                        {channel.note}
                      </span>
                    </span>
                    <span className="mt-1 block truncate text-[0.78rem] text-muted">{channel.value}</span>
                  </span>
                  <Icon
                    name="arrow"
                    className="size-4 shrink-0 text-muted transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-gold"
                  />
                </a>
              </Reveal>
            ))}

            <Reveal delay={210}>
              <p className="mt-6 flex items-start gap-2 text-[0.7rem] leading-relaxed text-muted/80">
                <Icon name="shield" className="mt-0.5 size-3.5 shrink-0 text-gold" />
                Email, phone and social handles are not published here to avoid fake or broken links. Ask
                for them through Fiverr and you&apos;ll receive the correct details directly.
              </p>
            </Reveal>

            <Reveal delay={260}>
              <div className="mt-6">
                <p className="label mb-2.5 !text-[0.52rem]">Social profiles</p>
                <div className="grid grid-cols-2 gap-2">
                  {SOCIALS.map((social) => (
                    <span
                      key={social.label}
                      aria-label={`${social.label} profile — coming soon`}
                      className="flex items-center justify-between rounded-lg border border-line bg-surface px-3 py-2.5"
                    >
                      <span className="text-[0.78rem] text-ink/80">{social.label}</span>
                      <span className="font-mono text-[0.42rem] uppercase tracking-[0.1em] text-muted/60">
                        {social.handle}
                      </span>
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>

          {/* form */}
          <Reveal delay={120} className="lg:col-span-7">
            <div className="premium-card p-5 sm:p-7">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="label !text-gold">Project brief</p>
                  <h3 className="mt-2 text-[1.3rem] font-medium tracking-[-0.02em]">Tell me about the idea.</h3>
                </div>
                <span className="grid size-9 shrink-0 place-items-center rounded-full border border-line text-gold">
                  <Icon name="chat" className="size-4" />
                </span>
              </div>

              {status === "prepared" ? (
                <div id="brief-result" className="fade-up mt-6" aria-live="polite">
                  <div className="flex items-start gap-3 rounded-xl border border-gold/30 bg-gold/[0.07] p-4">
                    <span className="grid size-8 shrink-0 place-items-center rounded-full bg-gold text-[#16120b]">
                      <Icon name="check" className="size-4" />
                    </span>
                    <div>
                      <p className="text-[0.9rem] font-medium text-ink">Your brief is ready, {values.name.split(" ")[0]}.</p>
                      <p className="mt-1 text-[0.78rem] leading-relaxed text-muted">
                        This page has no connected inbox yet, so nothing was sent automatically. Copy your
                        brief and send it through Fiverr — the preferred channel — and you&apos;ll get a reply
                        there.
                      </p>
                    </div>
                  </div>

                  <dl className="mt-4 space-y-2 rounded-xl border border-line bg-bg/30 p-4 font-mono text-[0.7rem]">
                    {[
                      ["Name", values.name],
                      ["Email", values.email],
                      ["Service", values.service],
                      ["Budget", values.budget],
                    ].map(([label, value]) => (
                      <div key={label} className="flex gap-3">
                        <dt className="w-16 shrink-0 uppercase tracking-[0.1em] text-muted">{label}</dt>
                        <dd className="min-w-0 flex-1 break-words text-ink/90">{value}</dd>
                      </div>
                    ))}
                    <div className="flex gap-3 border-t border-line pt-2">
                      <dt className="w-16 shrink-0 uppercase tracking-[0.1em] text-muted">Brief</dt>
                      <dd className="min-w-0 flex-1 whitespace-pre-wrap break-words text-ink/90">
                        {values.message}
                      </dd>
                    </div>
                  </dl>

                  <div className="mt-4 flex flex-col gap-2.5 sm:flex-row">
                    <button type="button" onClick={copyBrief} className="btn btn-ghost flex-1 !py-3 !text-[0.62rem]">
                      <Icon name={copyState === "copied" ? "check" : "copy"} className="size-3.5" />
                      {copyState === "copied" ? "Copied to clipboard" : "Copy brief"}
                    </button>
                    <a
                      href={FIVERR_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-gold flex-1 !py-3 !text-[0.62rem]"
                    >
                      Open Fiverr to send
                      <Icon name="arrow" className="size-3.5" />
                    </a>
                  </div>
                  {copyState === "failed" && (
                    <p className="mt-2 text-[0.7rem] text-danger" role="alert">
                      Clipboard access was blocked. Select the brief above and copy it manually.
                    </p>
                  )}

                  <button
                    type="button"
                    onClick={() => setStatus("idle")}
                    className="mt-3 inline-flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.12em] text-muted transition-colors hover:text-gold"
                  >
                    <Icon name="arrow" className="size-3 rotate-180" />
                    Edit the brief
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="mt-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="brief-name" className="mb-1.5 flex items-center justify-between font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">
                        Your name <span className="text-gold">*</span>
                      </label>
                      <input
                        id="brief-name"
                        name="name"
                        className="field"
                        placeholder="e.g. Alex Perera"
                        autoComplete="name"
                        value={values.name}
                        onChange={(e) => update("name", e.target.value)}
                        onBlur={() => handleBlur("name")}
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby={errors.name ? "error-name" : undefined}
                        required
                      />
                      <FieldError id="error-name">{errors.name}</FieldError>
                    </div>
                    <div>
                      <label htmlFor="brief-email" className="mb-1.5 flex items-center justify-between font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">
                        Email <span className="text-gold">*</span>
                      </label>
                      <input
                        id="brief-email"
                        name="email"
                        type="email"
                        inputMode="email"
                        className="field"
                        placeholder="you@company.com"
                        autoComplete="email"
                        value={values.email}
                        onChange={(e) => update("email", e.target.value)}
                        onBlur={() => handleBlur("email")}
                        aria-invalid={Boolean(errors.email)}
                        aria-describedby={errors.email ? "error-email" : undefined}
                        required
                      />
                      <FieldError id="error-email">{errors.email}</FieldError>
                    </div>
                    <div>
                      <label htmlFor="brief-service" className="mb-1.5 flex items-center justify-between font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">
                        Service <span className="text-gold">*</span>
                      </label>
                      <select
                        id="brief-service"
                        name="service"
                        className="field"
                        value={values.service}
                        onChange={(e) => update("service", e.target.value)}
                        onBlur={() => handleBlur("service")}
                        aria-invalid={Boolean(errors.service)}
                        aria-describedby={errors.service ? "error-service" : undefined}
                        required
                      >
                        <option value="">Select a service</option>
                        {SERVICE_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                      <FieldError id="error-service">{errors.service}</FieldError>
                      {prefilled && values.service && (
                        <button
                          type="button"
                          onClick={() => {
                            setValues((v) => ({ ...v, service: "" }));
                            setPrefilled(false);
                          }}
                          className="mt-1.5 inline-flex items-center gap-1 font-mono text-[0.5rem] uppercase tracking-[0.12em] text-gold/80 hover:text-gold"
                        >
                          <Icon name="check" className="size-2.5" /> Pre-filled from services — clear
                        </button>
                      )}
                    </div>
                    <div>
                      <label htmlFor="brief-budget" className="mb-1.5 flex items-center justify-between font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">
                        Budget range
                      </label>
                      <select
                        id="brief-budget"
                        name="budget"
                        className="field"
                        value={values.budget}
                        onChange={(e) => update("budget", e.target.value)}
                      >
                        {BUDGETS.map((budget) => (
                          <option key={budget} value={budget}>
                            {budget}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label htmlFor="brief-message" className="mb-1.5 flex items-center justify-between font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">
                        <span>
                          Project details <span className="text-gold">*</span>
                        </span>
                        <span className={cn("tabular-nums", values.message.length > 1900 ? "text-danger" : "text-muted/60")}>
                          {values.message.length} / 2000
                        </span>
                      </label>
                      <textarea
                        id="brief-message"
                        name="message"
                        rows={5}
                        className="field resize-y"
                        placeholder="What are you creating, who is it for, and when do you need it? A few lines is enough."
                        value={values.message}
                        onChange={(e) => update("message", e.target.value.slice(0, 2000))}
                        onBlur={() => handleBlur("message")}
                        aria-invalid={Boolean(errors.message)}
                        aria-describedby={errors.message ? "error-message" : undefined}
                        required
                      />
                      <FieldError id="error-message">{errors.message}</FieldError>
                    </div>
                  </div>

                  <div className="mt-5 flex flex-col gap-3 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-between">
                    <button type="submit" className="btn btn-gold group">
                      Prepare my brief
                      <Icon name="arrow" className="size-4 transition-transform group-hover:translate-x-0.5" />
                    </button>
                    <p className="flex items-start gap-2 text-[0.66rem] leading-relaxed text-muted/80 sm:max-w-[16rem]">
                      <Icon name="shield" className="mt-0.5 size-3 shrink-0 text-gold" />
                      Runs entirely in your browser. No data is sent or stored on a server.
                    </p>
                  </div>

                  <div className="sr-only" aria-live="polite">
                    {Object.values(errors).filter(Boolean).length
                      ? `Please review ${Object.values(errors).filter(Boolean).length} highlighted field(s).`
                      : ""}
                  </div>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
