import { useEffect, useState } from "react";
import { FIVERR_URL, NAV_LINKS, SERVICES } from "@/data";
import { Icon } from "@/components/Icons";
import { Availability, Logo } from "@/components/ui";
import { ThemeToggle } from "@/components/Nav";

function ColomboClock() {
  const [time, setTime] = useState("");

  useEffect(() => {
    const format = () => {
      try {
        return new Intl.DateTimeFormat("en-GB", {
          timeZone: "Asia/Colombo",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
        }).format(new Date());
      } catch {
        return new Date().toLocaleTimeString();
      }
    };
    setTime(format());
    const id = window.setInterval(() => setTime(format()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <span className="flex items-center gap-2 font-mono text-[0.58rem] uppercase tracking-[0.14em] text-muted">
      <Icon name="clock" className="size-3 text-gold" />
      Colombo
      <span className="tabular-nums text-ink/80" aria-live="off">
        {time || "--:--:--"}
      </span>
    </span>
  );
}

export function Footer({ theme, onToggleTheme }: { theme: "dark" | "light"; onToggleTheme: () => void }) {
  return (
    <footer className="relative z-10 border-t border-line">
      <div className="container-x pt-14">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-5">
            <Logo />
            <p className="mt-5 max-w-xs text-[0.84rem] leading-relaxed text-muted">
              Independent graphic designer and digital creator from Colombo, Sri Lanka — turning ideas into
              visual experiences that work.
            </p>
            <div className="mt-5">
              <Availability />
            </div>
            <a
              href={FIVERR_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-6 inline-flex items-center gap-2 rounded-full border border-line px-4 py-2.5 text-[0.72rem] font-medium transition-colors hover:border-gold"
            >
              <span className="grid size-6 place-items-center rounded-full border border-line text-gold">
                <Icon name="fiverr" className="size-3" />
              </span>
              fiverr.com/s/odWm2Lb
              <Icon name="arrow" className="size-3.5 text-muted transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </div>

          <nav aria-label="Footer navigation" className="md:col-span-2">
            <p className="label !text-gold">Explore</p>
            <ul className="mt-4 space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="link-underline text-[0.82rem] text-muted transition-colors hover:text-ink">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="md:col-span-3">
            <p className="label !text-gold">Services</p>
            <ul className="mt-4 space-y-2.5">
              {SERVICES.slice(0, 5).map((service) => (
                <li key={service.id}>
                  <a href="#services" className="link-underline text-[0.82rem] text-muted transition-colors hover:text-ink">
                    {service.title.replace(" Design", "").replace(" & ", " & ")}
                  </a>
                </li>
              ))}
              <li>
                <a href="#services" className="inline-flex items-center gap-1.5 text-[0.78rem] text-gold transition-opacity hover:opacity-80">
                  All twelve services
                  <Icon name="arrow" className="size-3" />
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <p className="label !text-gold">Connect</p>
            <ul className="mt-4 space-y-2.5">
              <li>
                <a href={FIVERR_URL} target="_blank" rel="noopener noreferrer" className="text-[0.82rem] text-muted transition-colors hover:text-ink">
                  Fiverr <span className="text-gold">↗</span>
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[0.82rem] text-muted transition-colors hover:text-ink">
                  Email — on request
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[0.82rem] text-muted transition-colors hover:text-ink">
                  WhatsApp — on request
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[0.82rem] text-muted transition-colors hover:text-ink">
                  Social — soon
                </a>
              </li>
            </ul>
          </div>
        </div>

        <a
          href="#top"
          aria-label="Back to top — Sahadh Fawmy"
          className="group mt-14 flex items-end justify-between gap-4 border-t border-line pt-8"
        >
          <span className="flex flex-wrap items-baseline gap-x-3 uppercase leading-[0.8] tracking-[-0.045em] sm:gap-x-5">
            <span className="text-[clamp(2.2rem,8vw,6.4rem)] font-medium text-ink/90 transition-colors group-hover:text-ink">
              Sahadh
            </span>
            <span className="font-display text-[clamp(2.4rem,8.6vw,6.8rem)] italic text-gold transition-opacity group-hover:opacity-80">
              Fawmy
            </span>
          </span>
          <span className="mb-2 hidden size-12 shrink-0 place-items-center rounded-full border border-line text-muted transition-all duration-300 group-hover:-translate-y-1 group-hover:border-gold group-hover:text-gold sm:grid">
            <Icon name="arrowUp" className="size-5" />
          </span>
        </a>

        <div className="mt-8 flex flex-col gap-4 border-t border-line py-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <p className="font-mono text-[0.55rem] uppercase tracking-[0.14em] text-muted">
              © {new Date().getFullYear()} Sahadh Fawmy · All rights reserved
            </p>
            <span className="hidden h-3 w-px bg-line-strong sm:block" />
            <p className="font-mono text-[0.53rem] uppercase tracking-[0.12em] text-muted/70">
              Concept visuals clearly labelled
            </p>
          </div>
          <div className="flex items-center gap-4">
            <ColomboClock />
            <ThemeToggle theme={theme} onToggle={onToggleTheme} className="size-8" />
          </div>
        </div>
      </div>
    </footer>
  );
}
