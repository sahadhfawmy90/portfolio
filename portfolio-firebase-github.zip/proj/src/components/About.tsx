import { useCountUp } from "@/hooks";
import { Icon } from "@/components/Icons";
import { Chip, CornerMarks, Reveal, SectionHead } from "@/components/ui";

function Stat({
  value,
  decimals = 0,
  suffix = "",
  label,
  sub,
  icon,
}: {
  value: number;
  decimals?: number;
  suffix?: string;
  label: string;
  sub: string;
  icon: string;
}) {
  const { ref, value: current } = useCountUp(value, decimals);
  return (
    <div className="group relative border-t border-line pt-5 transition-colors hover:border-gold/50">
      <div className="flex items-start justify-between">
        <p className="text-[clamp(1.8rem,3.4vw,2.4rem)] font-medium leading-none tracking-[-0.04em] text-ink">
          <span ref={ref} className="tabular-nums">
            {decimals ? current.toFixed(decimals) : current}
          </span>
          <span className="text-gold">{suffix}</span>
        </p>
        <Icon name={icon} className="size-4 text-muted transition-colors group-hover:text-gold" />
      </div>
      <p className="mt-3 text-[0.82rem] font-medium leading-tight text-ink">{label}</p>
      <p className="mt-1 font-mono text-[0.52rem] uppercase tracking-[0.14em] text-muted">{sub}</p>
    </div>
  );
}

function ProfileCard() {
  return (
    <div className="relative">
      <div
        aria-hidden="true"
        className="absolute -inset-4 rounded-[2.2rem] bg-[radial-gradient(60%_60%_at_30%_20%,rgba(155,131,245,0.18),transparent_70%),radial-gradient(50%_50%_at_90%_90%,rgba(214,182,139,0.14),transparent_70%)] blur-xl"
      />
      <div className="premium-card relative overflow-hidden p-6 sm:p-8">
        <CornerMarks />
        <div className="dot-grid pointer-events-none absolute inset-0 text-line-strong opacity-30" aria-hidden="true" />

        <div className="relative flex items-center justify-between">
          <span className="label !text-[0.52rem] !text-gold">Creative profile</span>
          <span className="font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">No. 001</span>
        </div>

        <div className="relative mt-8 grid grid-cols-[1fr_auto] items-start gap-4">
          <div>
            <h3 className="text-[1.65rem] font-medium uppercase leading-[0.95] tracking-[-0.03em]">
              Sahadh
              <br />
              <span className="font-display text-[2.3rem] italic normal-case tracking-normal text-gold-soft">
                Fawmy
              </span>
            </h3>
            <p className="mt-4 max-w-[22ch] text-[0.78rem] leading-relaxed text-muted">
              Graphic designer &amp; digital creator building visual identities with clarity and character.
            </p>
          </div>
          <div className="relative grid size-[4.6rem] shrink-0 place-items-center rounded-full border border-gold/30 bg-[linear-gradient(150deg,rgba(214,182,139,0.16),rgba(155,131,245,0.14))] sm:size-20">
            <span className="spin-slow absolute inset-1 rounded-full border border-dashed border-gold/25" aria-hidden="true" />
            <span className="font-display text-[2.1rem] italic leading-none text-gold-soft">SF</span>
          </div>
        </div>

        <div className="relative mt-8 grid grid-cols-2 gap-x-4 gap-y-5 border-t border-line pt-5">
          <div>
            <p className="font-mono text-[0.48rem] uppercase tracking-[0.18em] text-muted">Based in</p>
            <p className="mt-1.5 text-[0.76rem] font-medium">Colombo, Sri Lanka</p>
          </div>
          <div>
            <p className="font-mono text-[0.48rem] uppercase tracking-[0.18em] text-muted">Experience</p>
            <p className="mt-1.5 text-[0.76rem] font-medium">3.5+ years</p>
          </div>
          <div>
            <p className="font-mono text-[0.48rem] uppercase tracking-[0.18em] text-muted">Languages</p>
            <p className="mt-1.5 text-[0.76rem] font-medium">English · Arabic · Tamil</p>
          </div>
          <div>
            <p className="font-mono text-[0.48rem] uppercase tracking-[0.18em] text-muted">Status</p>
            <p className="mt-1.5 flex items-center gap-1.5 text-[0.76rem] font-medium">
              <span className="size-1.5 rounded-full bg-[#86d9a5]" /> Available
            </p>
          </div>
        </div>

        <div className="relative mt-6 flex items-end justify-between gap-3 border-t border-line pt-5">
          <div>
            <p className="font-display text-xl italic leading-none text-ink">Sahadh Fawmy</p>
            <p className="mt-1 font-mono text-[0.46rem] uppercase tracking-[0.18em] text-muted">
              Signature · Graphic design
            </p>
          </div>
          <div className="flex items-end gap-[2px]" aria-hidden="true">
            {[3, 6, 4, 8, 5, 7, 3, 6, 4, 5, 8, 4, 6, 3, 7, 5].map((h, i) => (
              <span key={i} className="w-[2px] bg-ink/50" style={{ height: `${h * 2.2}px` }} />
            ))}
          </div>
        </div>
      </div>

      <div className="glass floaty-slow absolute -bottom-5 -right-2 z-20 hidden rounded-2xl px-4 py-3 shadow-2xl sm:block">
        <p className="font-mono text-[0.48rem] uppercase tracking-[0.2em] text-muted">Focus</p>
        <p className="mt-1 text-[0.8rem] font-medium leading-none">Identity · Print · Digital</p>
      </div>
    </div>
  );
}

export function About() {
  return (
    <section id="about" className="section-pad">
      <div className="container-x">
        <SectionHead
          index="01"
          eyebrow="About the designer"
          title={
            <>
              A design eye with a <span className="serif-accent text-gold">strategist&apos;s</span> care.
            </>
          }
          intro="Design is more than making things look good. It is about making the message land — clearly, beautifully, and for the right audience."
        />

        <div className="mt-14 grid gap-14 lg:grid-cols-12 lg:gap-16">
          <Reveal className="lg:col-span-5">
            <div className="mx-auto max-w-md lg:sticky lg:top-28 lg:mx-0 lg:max-w-none">
              <ProfileCard />
              <div className="mt-12 flex flex-wrap items-center gap-2">
                <Chip>Identity</Chip>
                <Chip>Editorial</Chip>
                <Chip>Multilingual</Chip>
                <Chip>Digital</Chip>
              </div>
            </div>
          </Reveal>

          <div className="lg:col-span-7">
            <Reveal>
              <p className="text-[clamp(1.05rem,1.55vw,1.3rem)] leading-[1.65] text-ink">
                <span className="float-left mr-3 mt-1 font-display text-[3.4rem] leading-[0.78] text-gold">H</span>
                ello! I&apos;m Sahadh Fawmy, a Graphic Designer and Digital Creator from Colombo, Sri Lanka,
                with over <strong className="font-medium">3.5 years of experience</strong> in graphic design,
                photo editing, digital content creation, and document preparation.
              </p>
            </Reveal>

            <Reveal delay={80}>
              <p className="mt-6 text-[0.95rem] leading-relaxed text-muted">
                I help businesses, brands, and individuals transform their ideas into professional and
                visually engaging designs. Whether it is a new identity, a campaign, a publication or a
                single post, the goal is the same: work that feels considered and communicates at a glance.
              </p>
            </Reveal>

            <Reveal delay={140}>
              <p className="mt-4 text-[0.95rem] leading-relaxed text-muted">
                My approach combines creativity, attention to detail, modern design principles, and clear
                communication to deliver quality work. I work in English, Arabic and Tamil, which lets me
                shape visual systems that travel confidently across languages and markets.
              </p>
            </Reveal>

            <div className="mt-11 grid grid-cols-2 gap-x-6 gap-y-8 sm:grid-cols-4 sm:gap-x-5">
              <Reveal delay={40}>
                <Stat value={3.5} decimals={1} suffix="+" label="Years of experience" sub="Hands-on practice" icon="clock" />
              </Reveal>
              <Reveal delay={100}>
                <Stat value={12} label="Creative services" sub="One designer" icon="spark" />
              </Reveal>
              <Reveal delay={160}>
                <Stat value={3} label="Working languages" sub="Arabic · English · Tamil" icon="globe" />
              </Reveal>
              <Reveal delay={220}>
                <div className="group relative border-t border-line pt-5 transition-colors hover:border-gold/50">
                  <div className="flex items-start justify-between">
                    <p className="text-[clamp(1.5rem,3vw,2.1rem)] font-medium leading-none tracking-[-0.04em] text-ink">
                      Worldwide
                    </p>
                    <Icon name="compass" className="size-4 text-muted transition-colors group-hover:text-gold" />
                  </div>
                  <p className="mt-3 text-[0.82rem] font-medium leading-tight text-ink">International freelance</p>
                  <p className="mt-1 font-mono text-[0.52rem] uppercase tracking-[0.14em] text-muted">
                    Colombo → remote
                  </p>
                </div>
              </Reveal>
            </div>

            <div className="mt-12 grid gap-3 sm:grid-cols-3">
              {[
                { t: "Creative approach", d: "Original direction, never a copied template.", i: "spark" },
                { t: "Client-focused", d: "Your audience and goal lead every decision.", i: "shield" },
                { t: "International", d: "Remote-friendly across time zones.", i: "globe" },
              ].map((item, i) => (
                <Reveal key={item.t} delay={i * 70}>
                  <div className="group h-full rounded-2xl border border-line bg-surface p-4 transition-colors hover:border-gold/40">
                    <Icon name={item.i} className="size-4 text-gold" />
                    <p className="mt-3 text-[0.82rem] font-medium">{item.t}</p>
                    <p className="mt-1.5 text-[0.74rem] leading-relaxed text-muted">{item.d}</p>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={120}>
              <figure className="mt-12 border-l border-gold/40 pl-5">
                <blockquote className="font-display text-[clamp(1.25rem,2.2vw,1.6rem)] italic leading-snug text-ink/90">
                  “Good design does not decorate a message. It clarifies it.”
                </blockquote>
                <figcaption className="mt-2.5 font-mono text-[0.52rem] uppercase tracking-[0.18em] text-muted">
                  My working philosophy
                </figcaption>
              </figure>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
