import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { FIVERR_URL, PROJECT_CATEGORIES, PROJECTS, type Project } from "@/data";
import { Icon } from "@/components/Icons";
import { Chip, FiverrButton, MagneticLink, Reveal, SectionHead } from "@/components/ui";

function ProjectCard({
  project,
  index,
  onOpen,
  spanClass,
}: {
  project: Project;
  index: number;
  onOpen: () => void;
  spanClass: string;
}) {
  return (
    <article
      className={cn(
        "group relative w-full overflow-hidden rounded-2xl border border-line bg-panel text-left transition-colors duration-500 hover:border-gold/50 focus-within:border-gold/50",
        "h-[330px] sm:h-[360px] lg:h-[380px]",
        spanClass,
      )}
      style={{ animation: `fade-up .65s cubic-bezier(.2,.7,.2,1) ${index * 55}ms both` }}
    >
      <button
        type="button"
        onClick={onOpen}
        aria-label={`Open project details: ${project.title} (${project.category}, concept study)`}
        className="absolute inset-0 z-20 size-full rounded-2xl"
      />
      <div aria-hidden="true" className="image-frame absolute inset-0">
        <img
          src={project.image}
          alt={`${project.title} — ${project.subtitle}. Illustrative concept visual.`}
          className="size-full object-cover"
          loading={index < 3 ? "eager" : "lazy"}
          decoding="async"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,6,10,0.5)_0%,rgba(6,6,10,0.02)_35%,rgba(6,6,10,0.82)_100%)] transition-opacity duration-500 group-hover:opacity-90"
        />
      </div>

      <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-4">
        <span className="rounded-full border border-white/15 bg-black/35 px-2.5 py-1 font-mono text-[0.52rem] uppercase tracking-[0.16em] text-white/80 backdrop-blur-md">
          {project.category}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="rounded-full border border-white/15 bg-black/35 px-2.5 py-1 font-mono text-[0.5rem] uppercase tracking-[0.16em] text-white/60 backdrop-blur-md">
            Concept
          </span>
          <span className="font-mono text-[0.55rem] tracking-[0.14em] text-white/55">{project.year}</span>
        </span>
      </div>

      <div className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
        <div className="flex items-end justify-between gap-4">
          <div className="min-w-0">
            <p className="font-mono text-[0.52rem] uppercase tracking-[0.18em] text-gold-soft">{project.subtitle}</p>
            <h3 className="mt-1.5 truncate text-[1.15rem] font-medium tracking-[-0.02em] text-white sm:text-[1.3rem]">
              {project.title}
            </h3>
            <p className="mt-2 max-h-0 overflow-hidden text-[0.78rem] leading-relaxed text-white/65 opacity-0 transition-all duration-500 group-hover:max-h-16 group-hover:opacity-100 group-focus-within:max-h-16 group-focus-within:opacity-100">
              {project.blurb}
            </p>
          </div>
          <span
            aria-hidden="true"
            className="grid size-10 shrink-0 place-items-center rounded-full border border-white/25 bg-white/5 text-white backdrop-blur-md transition-all duration-500 group-hover:border-gold group-hover:bg-gold group-hover:text-[#16120b] group-focus-within:border-gold group-focus-within:bg-gold group-focus-within:text-[#16120b]"
          >
            <Icon name="arrow" className="size-4 -rotate-45 transition-transform duration-500 group-hover:rotate-0 group-focus-within:rotate-0" />
          </span>
        </div>
        <span className="mt-4 block h-px w-full origin-left scale-x-0 bg-gradient-to-r from-gold to-transparent transition-transform duration-700 group-hover:scale-x-100 group-focus-within:scale-x-100" />
      </div>
    </article>
  );
}

function Lightbox({
  project,
  position,
  total,
  onClose,
  onPrev,
  onNext,
}: {
  project: Project;
  position: number;
  total: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    document.body.classList.add("no-scroll");
    const previous = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
      if (e.key !== "Tab" || !panelRef.current) return;
      const nodes = panelRef.current.querySelectorAll<HTMLElement>('a[href], button:not([disabled])');
      if (!nodes.length) return;
      const list = Array.from(nodes);
      const first = list[0];
      const last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.classList.remove("no-scroll");
      document.removeEventListener("keydown", onKey);
      previous?.focus?.();
    };
  }, [onClose, onPrev, onNext]);

  return (
    <div
      className="fixed inset-0 z-[90] flex items-start justify-center overflow-y-auto bg-black/80 p-3 backdrop-blur-md sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-title"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={panelRef}
        className="fade-up relative my-auto w-full max-w-6xl overflow-hidden rounded-2xl border border-line-strong bg-panel shadow-2xl"
      >
        <div className="grid lg:grid-cols-[1.15fr_1fr]">
          <div className="relative bg-black">
            <div className="image-frame aspect-[4/3] lg:aspect-auto lg:h-full lg:min-h-[540px]">
              <img
                src={project.image}
                alt={`${project.title} — ${project.subtitle}. Illustrative concept visual.`}
                className="size-full object-cover"
              />
            </div>
            <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4">
              <span className="rounded-full border border-white/15 bg-black/40 px-2.5 py-1 font-mono text-[0.52rem] uppercase tracking-[0.16em] text-white/80 backdrop-blur-md">
                {project.category}
              </span>
              <span className="rounded-full border border-gold/30 bg-black/40 px-2.5 py-1 font-mono text-[0.5rem] uppercase tracking-[0.16em] text-gold-soft backdrop-blur-md">
                Illustrative concept
              </span>
            </div>
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
              <span className="font-mono text-[0.55rem] uppercase tracking-[0.18em] text-white/60">
                {String(position).padStart(2, "0")} / {String(total).padStart(2, "0")}
              </span>
              <span className="font-mono text-[0.55rem] uppercase tracking-[0.18em] text-white/60">SF — Portfolio</span>
            </div>
          </div>

          <div className="relative flex flex-col p-5 sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="label !text-[0.52rem] !text-gold">{project.subtitle}</p>
                <h3 id="lightbox-title" className="mt-2 text-[1.6rem] font-medium leading-tight tracking-[-0.03em] sm:text-[1.85rem]">
                  {project.title}
                </h3>
              </div>
              <button
                ref={closeRef}
                type="button"
                onClick={onClose}
                aria-label="Close project preview"
                className="grid size-9 shrink-0 place-items-center rounded-full border border-line bg-surface text-ink transition-colors hover:border-gold hover:text-gold"
              >
                <Icon name="close" className="size-4" />
              </button>
            </div>

            <div className="mt-4 flex flex-wrap gap-1.5">
              <Chip className="!text-gold-soft">{project.year}</Chip>
              <Chip>{project.category}</Chip>
              <Chip>Concept study</Chip>
            </div>

            <p className="mt-5 text-[0.88rem] leading-relaxed text-muted">{project.description}</p>

            <dl className="mt-6 grid grid-cols-2 gap-x-4 gap-y-5 border-t border-line pt-5">
              <div>
                <dt className="font-mono text-[0.5rem] uppercase tracking-[0.18em] text-muted">Deliverables</dt>
                <dd className="mt-2 space-y-1">
                  {project.deliverables.map((d) => (
                    <span key={d} className="block text-[0.78rem] leading-snug text-ink/90">
                      {d}
                    </span>
                  ))}
                </dd>
              </div>
              <div>
                <dt className="font-mono text-[0.5rem] uppercase tracking-[0.18em] text-muted">Tools &amp; skills</dt>
                <dd className="mt-2 space-y-1">
                  {project.tools.map((t) => (
                    <span key={t} className="block text-[0.78rem] leading-snug text-ink/90">
                      {t}
                    </span>
                  ))}
                </dd>
              </div>
            </dl>

            <div className="mt-6 rounded-xl border border-gold/20 bg-gold/[0.06] p-3.5">
              <p className="font-mono text-[0.5rem] uppercase tracking-[0.16em] text-gold">Please note</p>
              <p className="mt-1.5 text-[0.74rem] leading-relaxed text-muted">
                This is a self-initiated design concept, not a delivered client project. Visuals are
                illustrative placeholders and will be replaced with real client work as it is released.
              </p>
            </div>

            <div className="mt-6 flex flex-wrap gap-2.5">
              <a
                href={FIVERR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-gold flex-1 !px-4 !py-3 !text-[0.62rem]"
              >
                Request something similar
                <Icon name="arrow" className="size-3.5" />
              </a>
              <button type="button" onClick={onClose} className="btn btn-ghost !px-4 !py-3 !text-[0.62rem]">
                All work
              </button>
            </div>

            <div className="mt-auto flex items-center justify-between gap-3 border-t border-line pt-5">
              <button
                type="button"
                onClick={onPrev}
                className="group flex items-center gap-2 text-[0.68rem] uppercase tracking-[0.14em] text-muted transition-colors hover:text-ink"
              >
                <span className="grid size-8 place-items-center rounded-full border border-line transition-colors group-hover:border-gold">
                  <Icon name="arrow" className="size-3.5 rotate-180" />
                </span>
                Prev
              </button>
              <span className="label !text-[0.48rem]">Arrow keys to browse</span>
              <button
                type="button"
                onClick={onNext}
                className="group flex items-center gap-2 text-[0.68rem] uppercase tracking-[0.14em] text-muted transition-colors hover:text-ink"
              >
                Next
                <span className="grid size-8 place-items-center rounded-full border border-line transition-colors group-hover:border-gold">
                  <Icon name="arrow" className="size-3.5" />
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Work() {
  const [filter, setFilter] = useState<string>("All Work");
  const [active, setActive] = useState<number | null>(null);

  const filtered = useMemo(
    () => (filter === "All Work" ? PROJECTS : PROJECTS.filter((p) => p.category === filter)),
    [filter],
  );

  const close = useCallback(() => setActive(null), []);
  const prev = useCallback(
    () => setActive((i) => (i === null ? i : (i - 1 + filtered.length) % filtered.length)),
    [filtered.length],
  );
  const next = useCallback(
    () => setActive((i) => (i === null ? i : (i + 1) % filtered.length)),
    [filtered.length],
  );

  useEffect(() => {
    setActive(null);
  }, [filter]);

  const gridSpan = (project: Project) => {
    if (filter === "All Work") {
      return project.span === "wide" ? "sm:col-span-2 lg:col-span-8" : "lg:col-span-4";
    }
    if (filtered.length === 1) return "sm:col-span-2 lg:col-span-12";
    if (filtered.length === 2) return "sm:col-span-1 lg:col-span-6";
    return "lg:col-span-4";
  };

  return (
    <section id="work" className="section-pad relative">
      <div className="container-x">
        <SectionHead
          index="03"
          eyebrow="Selected work"
          title={
            <>
              A selection of <span className="serif-accent text-gold">concept</span> work.
            </>
          }
          intro="Self-initiated studies across identity, print, social and digital — a clear look at how I think, compose and finish a piece."
          aside={
            <p className="mt-4 flex items-start gap-2 border-l border-gold/40 pl-3 text-[0.72rem] leading-relaxed text-muted">
              <Icon name="shield" className="mt-0.5 size-3.5 shrink-0 text-gold" />
              Every piece below is clearly labelled as a concept study. No client names, awards or results
              are invented here.
            </p>
          }
        />

        <Reveal delay={60} className="mt-10">
          <div className="flex flex-col gap-4 border-y border-line py-4 lg:flex-row lg:items-center lg:justify-between">
            <div
              className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
              role="group"
              aria-label="Filter projects by category"
            >
              {PROJECT_CATEGORIES.map((category) => {
                const count =
                  category === "All Work" ? PROJECTS.length : PROJECTS.filter((p) => p.category === category).length;
                const isActive = filter === category;
                return (
                  <button
                    key={category}
                    type="button"
                    onClick={() => setFilter(category)}
                    aria-pressed={isActive}
                    className={cn(
                      "shrink-0 rounded-full border px-3.5 py-2 text-[0.7rem] tracking-[0.02em] transition-all duration-300",
                      isActive ? "filter-active" : "border-line text-muted hover:border-line-strong hover:text-ink",
                    )}
                  >
                    {category}
                    <span className={cn("ml-1.5 font-mono text-[0.55rem]", isActive ? "opacity-60" : "text-muted/60")}>
                      {String(count).padStart(2, "0")}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <span className="size-1.5 rounded-full bg-gold" />
              <span className="label !text-[0.52rem]">
                {String(filtered.length).padStart(2, "0")} projects · {filter === "All Work" ? "All categories" : filter}
              </span>
            </div>
          </div>
        </Reveal>

        <div key={filter} className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-12">
          {filtered.map((project, index) => (
            <ProjectCard
              key={project.id}
              project={project}
              index={index}
              spanClass={gridSpan(project)}
              onOpen={() => setActive(index)}
            />
          ))}

          {filter === "All Work" && (
            <div
              className="relative flex h-[330px] flex-col justify-between overflow-hidden rounded-2xl border border-gold/25 bg-[linear-gradient(150deg,rgba(214,182,139,0.14),rgba(155,131,245,0.1))] p-5 sm:h-[360px] lg:col-span-4 lg:h-[380px]"
              style={{ animation: "fade-up .65s cubic-bezier(.2,.7,.2,1) 480ms both" }}
            >
              <div className="dot-grid pointer-events-none absolute inset-0 text-gold/30 opacity-30" aria-hidden="true" />
              <div className="relative flex items-start justify-between">
                <span className="grid size-10 place-items-center rounded-xl border border-gold/30 bg-bg/20 text-gold">
                  <Icon name="plus" className="size-4" />
                </span>
                <span className="font-mono text-[0.52rem] uppercase tracking-[0.16em] text-muted">Next</span>
              </div>
              <div className="relative">
                <p className="font-mono text-[0.52rem] uppercase tracking-[0.18em] text-gold">Your project</p>
                <p className="mt-2 font-display text-[1.7rem] italic leading-[1.05] text-ink">
                  This space is waiting for your brand.
                </p>
                <MagneticLink href="#contact" variant="gold" className="mt-5 !px-5 !py-3 !text-[0.62rem]">
                  Start a project
                </MagneticLink>
              </div>
            </div>
          )}
        </div>

        <Reveal delay={80} className="mt-10 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <p className="max-w-xl text-[0.8rem] leading-relaxed text-muted">
            Real client work and full case studies are available on request. New pieces are added as
            projects are published.
          </p>
          <FiverrButton label="See my Fiverr profile" />
        </Reveal>
      </div>

      {active !== null && filtered[active] && (
        <Lightbox
          project={filtered[active]}
          position={active + 1}
          total={filtered.length}
          onClose={close}
          onPrev={prev}
          onNext={next}
        />
      )}
    </section>
  );
}
