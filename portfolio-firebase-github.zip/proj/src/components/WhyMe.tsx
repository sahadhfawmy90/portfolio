import { useState } from "react";
import { cn } from "@/utils/cn";
import { PROCESS, REASONS } from "@/data";
import { Icon } from "@/components/Icons";
import { Availability, FiverrButton, Reveal } from "@/components/ui";

function ReasonRow({
  reason,
  isOpen,
  onToggle,
  index,
}: {
  reason: (typeof REASONS)[number];
  isOpen: boolean;
  onToggle: () => void;
  index: number;
}) {
  return (
    <Reveal delay={index * 45}>
      <div
        className={cn(
          "group relative overflow-hidden border-b border-line transition-colors",
          isOpen ? "bg-surface" : "hover:bg-surface/60",
        )}
      >
        <span
          aria-hidden="true"
          className={cn(
            "absolute inset-y-0 left-0 w-px bg-gold transition-opacity duration-500",
            isOpen ? "opacity-100" : "opacity-0 group-hover:opacity-60",
          )}
        />
        <h3>
          <button
            type="button"
            onClick={onToggle}
            aria-expanded={isOpen}
            aria-controls={`reason-panel-${reason.n}`}
            id={`reason-button-${reason.n}`}
            className="flex w-full items-center gap-4 px-3 py-5 text-left sm:gap-5 sm:px-5"
          >
            <span className="font-mono text-[0.58rem] tracking-[0.16em] text-gold/80">{reason.n}</span>
            <span className="grid size-9 shrink-0 place-items-center rounded-lg border border-line bg-bg/40 text-muted transition-colors group-hover:text-gold">
              <Icon name={reason.icon} className="size-4" />
            </span>
            <span className="flex-1 text-[0.98rem] font-medium tracking-[-0.01em] text-ink sm:text-[1.05rem]">
              {reason.title}
            </span>
            <span
              aria-hidden="true"
              className={cn(
                "grid size-7 shrink-0 place-items-center rounded-full border transition-all duration-300",
                isOpen ? "rotate-45 border-gold/60 text-gold" : "border-line text-muted group-hover:border-gold/40 group-hover:text-gold",
              )}
            >
              <Icon name="plus" className="size-3.5" />
            </span>
          </button>
        </h3>
        <div
          id={`reason-panel-${reason.n}`}
          role="region"
          aria-labelledby={`reason-button-${reason.n}`}
          className={cn(
            "grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(.2,.7,.2,1)]",
            isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
          )}
        >
          <div className="overflow-hidden">
            <p className="max-w-xl pb-5 pl-[4.4rem] pr-10 text-[0.82rem] leading-relaxed text-muted sm:pl-[5.1rem]">
              {reason.body}
            </p>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export function WhyMe() {
  const [open, setOpen] = useState<string | null>("01");

  return (
    <section className="relative border-y border-line bg-[color-mix(in_srgb,var(--panel)_45%,transparent)]">
      <div className="section-pad container-x">
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <Reveal className="flex items-center gap-4">
                <span className="label !text-gold">05</span>
                <span className="h-px w-10 bg-gold/50" />
                <span className="label">Why work with me</span>
              </Reveal>
              <Reveal delay={80}>
                <h2 className="mt-6 text-balance text-[clamp(2.1rem,4.4vw,3.6rem)] font-medium leading-[1.03] tracking-[-0.035em]">
                  A reliable partner, not just a{" "}
                  <span className="serif-accent text-gold">file.</span>
                </h2>
              </Reveal>
              <Reveal delay={140}>
                <p className="mt-5 max-w-sm text-[0.92rem] leading-relaxed text-muted">
                  Design projects go better when communication is clear, deadlines are respected and the
                  details are handled. That is the standard I work to on every brief.
                </p>
              </Reveal>

              <Reveal delay={200}>
                <div className="premium-card mt-8 max-w-sm p-5">
                  <div className="flex items-start justify-between">
                    <p className="label !text-gold">The short version</p>
                    <span className="font-display text-2xl italic leading-none text-gold/70">07</span>
                  </div>
                  <ul className="mt-4 space-y-2.5">
                    {[
                      { i: "compass", t: "Colombo based, working worldwide" },
                      { i: "globe", t: "English, Arabic & Tamil layouts" },
                      { i: "clock", t: "Milestones agreed before we start" },
                      { i: "chat", t: "Plain-language updates throughout" },
                    ].map((item) => (
                      <li key={item.t} className="flex items-center gap-2.5 text-[0.8rem] text-ink/90">
                        <Icon name={item.i} className="size-3.5 shrink-0 text-gold" />
                        {item.t}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
                    <Availability />
                  </div>
                  <FiverrButton label="Start a conversation" className="mt-4 w-full !py-3 !text-[0.62rem]" />
                </div>
              </Reveal>
            </div>
          </div>

          <div className="lg:col-span-7">
            <Reveal>
              <p className="mb-3 flex items-center justify-between border-b border-line pb-3">
                <span className="label">Seven reasons</span>
                <span className="label !text-[0.5rem]">Tap to expand</span>
              </p>
            </Reveal>
            <div>
              {REASONS.map((reason, index) => (
                <ReasonRow
                  key={reason.n}
                  reason={reason}
                  index={index}
                  isOpen={open === reason.n}
                  onToggle={() => setOpen(open === reason.n ? null : reason.n)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* process */}
        <div className="mt-20 border-t border-line pt-12 md:mt-24">
          <Reveal className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="label !text-gold">How we&apos;ll work</p>
              <h3 className="mt-2 font-display text-[clamp(1.7rem,3vw,2.3rem)] italic text-ink">
                A simple, four-step process.
              </h3>
            </div>
            <p className="max-w-xs text-[0.76rem] leading-relaxed text-muted">
              No mystery, no endless revisions loop. Just a clear route from idea to final files.
            </p>
          </Reveal>

          <div className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {PROCESS.map((step, i) => (
              <Reveal key={step.n} delay={i * 70} className="h-full">
                <div className="group relative h-full bg-[color-mix(in_srgb,var(--panel)_92%,transparent)] p-5 transition-colors hover:bg-panel sm:p-6">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[0.62rem] tracking-[0.16em] text-gold">{step.n}</span>
                    <span className="size-1.5 rounded-full bg-line-strong transition-colors group-hover:bg-gold" />
                  </div>
                  <p className="mt-7 text-[1rem] font-medium">{step.title}</p>
                  <p className="mt-2 text-[0.78rem] leading-relaxed text-muted">{step.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
