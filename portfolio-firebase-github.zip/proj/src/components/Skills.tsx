import { SKILL_GROUPS } from "@/data";
import { Icon } from "@/components/Icons";
import { FiverrButton, Reveal, SectionHead } from "@/components/ui";

const SCRIPTS = [
  { glyph: "Aa", label: "English", note: "Latin typography", lang: "en" },
  { glyph: "أ", label: "العربية", note: "Arabic typography", lang: "ar" },
  { glyph: "அ", label: "தமிழ்", note: "Tamil typography", lang: "ta" },
];

const TOOLS = [
  { name: "Adobe Photoshop", short: "Ps", area: "Retouch · Composite" },
  { name: "Adobe Illustrator", short: "Ai", area: "Vector · Identity" },
  { name: "HTML & CSS", short: "</>", area: "Responsive layouts" },
  { name: "AI video tools", short: "AI", area: "Frames · Motion" },
  { name: "Office documents", short: "Doc", area: "Arabic · Formatting" },
];

export function Skills() {
  return (
    <section id="skills" className="section-pad relative overflow-hidden">
      <div aria-hidden="true" className="orb pointer-events-none absolute -right-32 top-24 size-96 bg-violet/10" />
      <div className="container-x relative">
        <SectionHead
          index="04"
          eyebrow="Capabilities"
          title={
            <>
              A toolkit built for <span className="serif-accent text-gold">visual</span> problems.
            </>
          }
          intro="The disciplines I practise every week — from the first sketch of a mark to the final export, across three scripts."
          aside={
            <p className="mt-4 flex items-start gap-2 rounded-xl border border-line bg-surface p-3 text-[0.72rem] leading-relaxed text-muted">
              <Icon name="shield" className="mt-0.5 size-3.5 shrink-0 text-gold" />
              No certifications or proficiency scores are claimed here. These are the areas I actively
              work in.
            </p>
          }
        />

        <div className="mt-12 grid gap-8 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-7">
            <div className="space-y-8">
              {SKILL_GROUPS.map((group, groupIndex) => (
                <Reveal key={group.id} delay={groupIndex * 80}>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-[0.55rem] tracking-[0.16em] text-gold">
                      {String(groupIndex + 1).padStart(2, "0")}
                    </span>
                    <h3 className="font-mono text-[0.6rem] uppercase tracking-[0.2em] text-muted">{group.label}</h3>
                    <span className="h-px flex-1 bg-line" />
                    <span className="font-mono text-[0.52rem] text-muted/60">{String(group.items.length).padStart(2, "0")}</span>
                  </div>

                  <ul className="mt-2">
                    {group.items.map((item) => (
                      <li key={item}>
                        <div className="group relative flex items-center justify-between gap-4 border-b border-line py-3.5 transition-colors">
                          <span
                            aria-hidden="true"
                            className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-gradient-to-r from-gold via-gold/50 to-transparent transition-transform duration-700 group-hover:scale-x-100"
                          />
                          <span className="flex items-center gap-3">
                            <span className="size-1 rounded-full bg-muted/50 transition-colors duration-300 group-hover:bg-gold" />
                            <span className="text-[0.95rem] text-ink/90 transition-colors group-hover:text-ink sm:text-[1rem]">
                              {item}
                            </span>
                          </span>
                          <span className="flex shrink-0 items-center gap-2">
                            <span className="hidden font-mono text-[0.5rem] uppercase tracking-[0.14em] text-muted/0 transition-colors duration-300 group-hover:text-muted/80 sm:block">
                              Practice area
                            </span>
                            <Icon
                              name="arrow"
                              className="size-3.5 -rotate-45 text-muted/40 transition-all duration-300 group-hover:rotate-0 group-hover:text-gold"
                            />
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </Reveal>
              ))}
            </div>

            <Reveal delay={120}>
              <div className="mt-8 flex items-center gap-3 rounded-xl border border-gold/20 bg-gold/[0.05] px-4 py-3">
                <Icon name="spark" className="size-4 shrink-0 text-gold" />
                <p className="text-[0.76rem] leading-relaxed text-muted">
                  <span className="text-ink">3.5+ years</span> of hands-on practice — the real measure is the
                  work, not a badge.
                </p>
              </div>
            </Reveal>
          </div>

          <div className="space-y-4 lg:col-span-5">
            <Reveal>
              <div className="premium-card relative p-5 sm:p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="label !text-gold">Multilingual by design</p>
                    <p className="mt-2 max-w-[28ch] font-display text-[1.5rem] italic leading-tight text-ink">
                      One visual language, three scripts.
                    </p>
                  </div>
                  <span className="grid size-9 place-items-center rounded-full border border-line text-gold">
                    <Icon name="globe" className="size-4" />
                  </span>
                </div>

                <div className="mt-6 grid grid-cols-3 divide-x divide-line overflow-hidden rounded-xl border border-line bg-bg/30">
                  {SCRIPTS.map((script) => (
                    <div key={script.label} className="group px-2 py-5 text-center transition-colors hover:bg-surface">
                      <span
                        lang={script.lang}
                        className="block text-[2rem] leading-none text-gold-soft transition-transform duration-500 group-hover:-translate-y-0.5 sm:text-[2.4rem]"
                      >
                        {script.glyph}
                      </span>
                      <span lang={script.lang} className="mt-3 block text-[0.72rem] font-medium text-ink">
                        {script.label}
                      </span>
                      <span className="mt-1 block font-mono text-[0.45rem] uppercase tracking-[0.1em] text-muted">
                        {script.note}
                      </span>
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-[0.76rem] leading-relaxed text-muted">
                  Layouts that respect direction, line height and letterform — not translations forced into
                  a Latin grid.
                </p>
              </div>
            </Reveal>

            <Reveal delay={90}>
              <div className="premium-card p-5 sm:p-6">
                <div className="flex items-center justify-between">
                  <p className="label">Working toolkit</p>
                  <Icon name="layers" className="size-4 text-gold" />
                </div>
                <ul className="mt-4 space-y-1">
                  {TOOLS.map((tool) => (
                    <li
                      key={tool.name}
                      className="group flex items-center gap-3 rounded-lg border border-transparent px-2 py-2.5 transition-colors hover:border-line hover:bg-surface"
                    >
                      <span className="grid size-8 shrink-0 place-items-center rounded-md border border-line bg-bg/40 font-mono text-[0.58rem] text-gold">
                        {tool.short}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[0.8rem] font-medium text-ink">{tool.name}</span>
                        <span className="block truncate font-mono text-[0.46rem] uppercase tracking-[0.12em] text-muted">
                          {tool.area}
                        </span>
                      </span>
                      <Icon name="check" className="size-3.5 text-muted/40 transition-colors group-hover:text-gold" />
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div className="relative overflow-hidden rounded-2xl border border-gold/25 bg-[linear-gradient(140deg,rgba(214,182,139,0.16),rgba(155,131,245,0.1))] p-5 sm:p-6">
                <div className="dot-grid pointer-events-none absolute inset-0 text-gold/40 opacity-20" aria-hidden="true" />
                <p className="relative font-display text-[1.4rem] italic leading-tight text-ink">
                  Need a second pair of eyes on a brief?
                </p>
                <p className="relative mt-2 text-[0.78rem] leading-relaxed text-muted">
                  Send it over with no obligation. I&apos;ll tell you honestly what it needs.
                </p>
                <FiverrButton label="Ask a question" className="relative mt-4 !px-5 !py-3 !text-[0.62rem]" />
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
