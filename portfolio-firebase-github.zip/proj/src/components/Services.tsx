import { SERVICES, type Service } from "@/data";
import { useTilt } from "@/hooks";
import { Icon } from "@/components/Icons";
import { Availability, FiverrButton, Reveal, SectionHead } from "@/components/ui";

function ServiceCard({ service, index, onSelect }: { service: Service; index: number; onSelect: (title: string) => void }) {
  const tilt = useTilt(3.5);

  return (
    <div
      ref={tilt.ref}
      onPointerMove={tilt.onPointerMove}
      onPointerLeave={tilt.onPointerLeave}
      className="tilt group relative h-full overflow-hidden rounded-2xl border border-line bg-[color-mix(in_srgb,var(--panel)_68%,transparent)] p-5 transition-colors duration-500 hover:border-gold/45 focus-within:border-gold/45 sm:p-6"
    >
      <div aria-hidden="true" className="spotlight pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-within:opacity-100" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-6 -top-6 size-24 rounded-full border border-line opacity-0 transition-all duration-700 group-hover:scale-125 group-hover:opacity-100"
      />

      <div className="relative flex items-start justify-between">
        <span className="grid size-11 place-items-center rounded-xl border border-line bg-surface text-gold transition-colors duration-500 group-hover:border-gold/40 group-hover:bg-gold/10">
          <Icon name={service.icon} className="size-5" />
        </span>
        <span className="font-mono text-[0.58rem] tracking-[0.16em] text-muted/60">
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>

      <h3 className="relative mt-5 text-[1.02rem] font-medium leading-snug tracking-[-0.015em] text-ink">
        {service.title}
      </h3>
      <p className="relative mt-2.5 text-[0.8rem] leading-relaxed text-muted">{service.description}</p>

      <div className="relative mt-5 flex flex-wrap items-center gap-1.5 pt-1">
        {service.tags.map((tag) => (
          <span
            key={tag}
            className="rounded-full border border-line px-2 py-0.5 font-mono text-[0.5rem] uppercase tracking-[0.12em] text-muted"
          >
            {tag}
          </span>
        ))}
      </div>

      <button
        type="button"
        onClick={() => onSelect(service.title)}
        className="relative mt-5 flex w-full items-center justify-between border-t border-line pt-3.5 text-left text-[0.7rem] font-medium uppercase tracking-[0.14em] text-muted transition-colors hover:text-gold"
      >
        <span>Start a project</span>
        <span className="grid size-7 place-items-center rounded-full border border-line transition-all duration-300 group-hover:border-gold/50 group-hover:text-gold">
          <Icon name="arrow" className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
        </span>
      </button>
    </div>
  );
}

export function Services({ onSelectService }: { onSelectService: (title: string) => void }) {
  return (
    <section id="services" className="section-pad relative">
      <div className="container-x">
        <SectionHead
          index="02"
          eyebrow="Services"
          title={
            <>
              Everything your brand needs,{" "}
              <span className="serif-accent text-gold">designed with intent.</span>
            </>
          }
          intro="Twelve focused services across identity, print and digital. Choose one, or combine them into a complete visual system for your brand."
          aside={
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Availability />
              <span className="label !text-[0.52rem]">Remote · Worldwide</span>
            </div>
          }
        />

        <div className="mt-12 grid gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
          {SERVICES.map((service, index) => (
            <Reveal key={service.id} delay={(index % 3) * 70} className="h-full">
              <ServiceCard service={service} index={index} onSelect={onSelectService} />
            </Reveal>
          ))}
        </div>

        <Reveal delay={80} className="mt-12">
          <div className="relative overflow-hidden rounded-2xl border border-line bg-[linear-gradient(120deg,color-mix(in_srgb,var(--panel)_75%,transparent),color-mix(in_srgb,var(--violet)_8%,transparent))] p-6 sm:p-8">
            <div aria-hidden="true" className="orb absolute -right-10 -top-16 size-52 bg-violet/20" />
            <div aria-hidden="true" className="orb absolute -bottom-16 left-1/4 size-40 bg-gold/10" />
            <div className="relative flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
              <div>
                <p className="label !text-gold">Tailored, not templated</p>
                <p className="mt-2 max-w-2xl font-display text-[clamp(1.35rem,2.4vw,1.9rem)] italic leading-snug text-ink">
                  Not sure which service you need? Describe the idea — I&apos;ll recommend the right format.
                </p>
              </div>
              <div className="flex shrink-0 flex-wrap gap-3">
                <FiverrButton label="Discuss on Fiverr" />
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
