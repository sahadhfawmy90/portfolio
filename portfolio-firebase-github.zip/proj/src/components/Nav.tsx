import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { FIVERR_URL, NAV_LINKS } from "@/data";
import { scrollToElement, useScrolled } from "@/hooks";
import { Icon } from "@/components/Icons";
import { Availability, Logo } from "@/components/ui";

type Theme = "dark" | "light";

export function ThemeToggle({
  theme,
  onToggle,
  className,
}: {
  theme: Theme;
  onToggle: () => void;
  className?: string;
}) {
  const next = theme === "dark" ? "light" : "dark";
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={`Switch to ${next} mode`}
      title={`Switch to ${next} mode`}
      className={cn(
        "group relative grid size-10 place-items-center overflow-hidden rounded-full border border-line bg-surface text-ink transition-colors hover:border-gold/60 hover:text-gold",
        className,
      )}
    >
      <Icon
        name={theme === "dark" ? "sun" : "moon"}
        className="size-[17px] transition-transform duration-500 group-hover:rotate-45"
      />
    </button>
  );
}

export function Nav({ theme, onToggleTheme }: { theme: Theme; onToggleTheme: () => void }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [progress, setProgress] = useState(0);
  const scrolled = useScrolled(30);
  const menuRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const ids = ["work", "services", "about", "skills", "contact"];
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (!sections.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-38% 0px -55% 0px", threshold: 0 },
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    let frame = 0;
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const onChange = (e: MediaQueryListEvent) => {
      if (e.matches) setOpen(false);
    };
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, []);

  useEffect(() => {
    if (!open) return;
    closeRef.current?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
      }
      if (e.key !== "Tab") return;
      const nodes = menuRef.current?.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );
      if (!nodes || nodes.length === 0) return;
      const list = Array.from(nodes);
      const first = list[0];
      const last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    document.body.classList.add("no-scroll");
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.classList.remove("no-scroll");
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50">
        <div className="h-px w-full bg-line/60">
          <div
            className="h-px bg-gradient-to-r from-gold via-lav to-violet transition-[width] duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div
          className={cn(
            "transition-all duration-500",
            scrolled
              ? "border-b border-line bg-[var(--nav-glass)] backdrop-blur-xl"
              : "border-b border-transparent bg-transparent",
          )}
        >
          <div className="container-x flex h-[70px] items-center justify-between gap-4 md:h-[80px]">
            <Logo />

            <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  aria-current={active === link.href.slice(1) ? "true" : undefined}
                  className={cn(
                    "link-underline relative rounded-full px-3.5 py-2 text-[0.78rem] font-medium tracking-wide transition-colors",
                    active === link.href.slice(1) ? "text-ink" : "text-muted hover:text-ink",
                  )}
                  data-active={active === link.href.slice(1)}
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2.5">
              <ThemeToggle theme={theme} onToggle={onToggleTheme} />
              <a
                href={FIVERR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-gold hidden !px-5 !py-3 !text-[0.66rem] sm:inline-flex"
              >
                <span>Let&apos;s work</span>
                <Icon name="arrow" className="size-3.5" />
              </a>
              <button
                ref={triggerRef}
                type="button"
                onClick={() => setOpen(true)}
                aria-label="Open menu"
                aria-expanded={open}
                aria-controls="mobile-menu"
                className="grid size-10 place-items-center rounded-full border border-line bg-surface text-ink transition-colors hover:border-gold/60 lg:hidden"
              >
                <span className="flex w-4 flex-col gap-[5px]">
                  <span className="h-px w-full bg-current" />
                  <span className="h-px w-full bg-current" />
                  <span className="h-px w-2/3 bg-current" />
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        ref={menuRef}
        id="mobile-menu"
        role="dialog"
        aria-modal="true"
        aria-label="Site menu"
        className={cn(
          "fixed inset-0 z-[60] flex flex-col bg-bg transition-[opacity,visibility] duration-500 lg:hidden",
          open ? "visible opacity-100" : "invisible opacity-0",
        )}
      >
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
          <div className="orb absolute -right-20 top-10 size-72 bg-violet/20" />
          <div className="orb absolute -left-24 bottom-10 size-72 bg-gold/10" />
          <div className="dot-grid absolute inset-0 text-line-strong opacity-40" />
        </div>

        <div className="container-x relative flex h-[70px] shrink-0 items-center justify-between">
          <Logo />
          <div className="flex items-center gap-2.5">
            <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            <button
              ref={closeRef}
              type="button"
              onClick={() => {
                setOpen(false);
                triggerRef.current?.focus();
              }}
              aria-label="Close menu"
              className="grid size-10 place-items-center rounded-full border border-line bg-surface text-ink transition-colors hover:border-gold hover:text-gold"
            >
              <Icon name="close" className="size-4" />
            </button>
          </div>
        </div>

        <div className="container-x relative flex flex-1 flex-col overflow-y-auto pb-8 pt-2">
          <div className="m-auto flex w-full flex-col justify-center py-2">
          <p className="label mb-6">Navigate</p>
          <nav aria-label="Mobile primary" className="flex flex-col">
            {NAV_LINKS.map((link, i) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(event) => {
                  event.preventDefault();
                  setOpen(false);
                  const href = link.href;
                  window.setTimeout(() => {
                    scrollToElement(document.querySelector(href), "start");
                    history.replaceState(null, "", href);
                  }, 80);
                }}
                className="group flex items-baseline justify-between border-b border-line py-3.5"
                style={{ animation: open ? `fade-up .6s cubic-bezier(.2,.7,.2,1) ${120 + i * 55}ms both` : undefined }}
              >
                <span className="flex items-baseline gap-3">
                  <span className="size-1.5 rounded-full bg-gold/60 transition-colors group-hover:bg-gold" />
                  <span className="text-[2rem] font-medium tracking-[-0.035em] transition-colors group-hover:text-gold">
                    {link.label}
                  </span>
                </span>
                <Icon name="arrow" className="size-5 -rotate-45 text-muted transition-all group-hover:rotate-0 group-hover:text-gold" />
              </a>
            ))}
          </nav>
          <div className="mt-8 space-y-5">
            <Availability />
            <a
              href={FIVERR_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-gold w-full"
            >
              Hire me on Fiverr
              <Icon name="arrow" className="size-4" />
            </a>
            <div className="flex items-center justify-between">
              <span className="label">Colombo, Sri Lanka</span>
              <span className="label">GMT +5:30</span>
            </div>
          </div>
          </div>
        </div>
      </div>
    </>
  );
}
