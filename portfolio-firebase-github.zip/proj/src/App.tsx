import { useCallback, useEffect, useState } from "react";
import { Nav } from "@/components/Nav";
import { Preloader } from "@/components/Preloader";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { About } from "@/components/About";
import { Services } from "@/components/Services";
import { Work } from "@/components/Work";
import { Skills } from "@/components/Skills";
import { WhyMe } from "@/components/WhyMe";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { scrollToElement, useRevealObserver } from "@/hooks";

type Theme = "dark" | "light";

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof document === "undefined") return "dark";
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  });
  const [loading, setLoading] = useState(true);
  const [interest, setInterest] = useState({ title: "", id: 0 });

  useRevealObserver(!loading);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem("sf-theme", theme);
    } catch {
      /* storage may be unavailable — theme still applies for this visit */
    }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "dark" ? "#06060a" : "#f3f0e9");
  }, [theme]);

  useEffect(() => {
    document.body.classList.toggle("no-scroll", loading);
    return () => document.body.classList.remove("no-scroll");
  }, [loading]);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "dark" ? "light" : "dark"));
  }, []);

  const finishLoading = useCallback(() => setLoading(false), []);

  const selectService = useCallback((title: string) => {
    setInterest({ title, id: Date.now() });
    scrollToElement(document.getElementById("contact"), "start");
    window.setTimeout(() => {
      document.getElementById("brief-service")?.focus({ preventScroll: true });
    }, 750);
  }, []);

  return (
    <div className="relative min-h-screen overflow-x-clip">
      <a
        href="#main-content"
        className="skip-link sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[110] focus:rounded-full focus:bg-gold focus:px-5 focus:py-3 focus:text-[0.75rem] focus:font-semibold focus:uppercase focus:tracking-[0.12em] focus:text-[#16120b]"
      >
        Skip to content
      </a>

      {loading && <Preloader onDone={finishLoading} />}

      <Nav theme={theme} onToggleTheme={toggleTheme} />

      <main id="main-content">
        <Hero />
        <Marquee />
        <About />
        <Services onSelectService={selectService} />
        <Work />
        <Skills />
        <WhyMe />
        <Contact interest={interest} />
      </main>

      <Footer theme={theme} onToggleTheme={toggleTheme} />
    </div>
  );
}
