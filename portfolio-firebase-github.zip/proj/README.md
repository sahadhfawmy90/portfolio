# Sahadh Fawmy — Portfolio

React + Vite + Tailwind. Hosted on Firebase Hosting, deployed from GitHub.

## Run locally
    npm install
    npm run dev

## One-time setup (Firebase + GitHub)
1. Create a project at https://console.firebase.google.com and note its **Project ID**.
2. Replace `YOUR_FIREBASE_PROJECT_ID` in `.firebaserc` and in both files in `.github/workflows/`.
3. Install the CLI and link GitHub (this creates the service-account secret for you):
       npm i -g firebase-tools
       firebase login
       firebase init hosting:github
   When asked: public directory `dist`, single-page app `Yes`, set up builds `No`
   (the workflows already exist), keep existing files.
4. Push to `main` — GitHub Actions builds and deploys to `https://<project-id>.web.app`.
   Pull requests get preview URLs automatically.
